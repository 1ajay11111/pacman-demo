using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatedSprite : MonoBehaviour
{
    public SpriteRenderer _spriteRenderer { get; private set; }
    public Sprite[] _sprites;
    public float _animationtime = 0.25f;
    public int _animationFrame { get; private set; }
    public bool _loop = true;
    private void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }
    private void Start()
    {
        InvokeRepeating(nameof(Advance), _animationtime, _animationtime);
    }
    public void Advance()
    {
        if (!_spriteRenderer.enabled)
        {
            return;
        }
        _animationFrame++;
        if (_animationFrame >= _sprites.Length && _loop)
        {
            _animationFrame = 0;
        }
        if (_animationFrame >= 0 && _animationFrame < _sprites.Length)
        {
            _spriteRenderer.sprite = _sprites[_animationFrame];
        }
    }
    public void Restart()
    {
        _animationFrame = -1;
        Advance();
    }
}
