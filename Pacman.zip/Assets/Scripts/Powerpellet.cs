using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Powerpellet : Pellet
{
    public float _duration = 8f;


    protected override void Eat()
    {
        FindObjectOfType<Gamemanager>().PowerpelletEaten(this);
    }
}
