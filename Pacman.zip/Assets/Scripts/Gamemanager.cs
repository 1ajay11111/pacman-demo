using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Gamemanager : MonoBehaviour
{
    /* public static Gamemanager Instance { get; private set; }*/
    public Ghost[] _ghosts;
    public Pacman _pacman;
    public Transform _pellets;

    public int _ghostMultiplier { get; private set; } = 1;
    public int score { get; private set; }
    public int lives { get; private set; }

    /*private void Awake()
    {
        if (Instance != null)
        {
            DestroyImmediate(gameObject);
        }
        else
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }*/
    private void Start()
    {
        NewGame();
    }

    private void Update()
    {
        if (this.lives <= 0 && Input.anyKey)
            NewGame();
    }

    private void NewGame()
    {
        SetScore(0);
        SetLives(3);
        NewRound();
    }

    public void NewRound()
    {
        foreach (Transform pellets in this._pellets)
        {
            pellets.gameObject.SetActive(true);
        }
        ResetState();
    }

    private void ResetState()
    {
        ResetGhostMultiplier();
        for (int i = 0; i < this._ghosts.Length; i++)
        {
            this._ghosts[i].gameObject.SetActive(true);
        }
        _pacman.gameObject.SetActive(true);
    }

    private void GameOver()
    {
        for (int i = 0; i < this._ghosts.Length; i++)
        {
            this._ghosts[i].gameObject.SetActive(false);
        }
        _pacman.gameObject.SetActive(false);
    }

    private void SetScore(int score)
    {
        this.score = score;
    }

    private void SetLives(int lives)
    {
        this.lives = lives;
    }

    public void GhostEaten(Ghost ghost)
    {
        int points = ghost.points * _ghostMultiplier;
        SetScore(this.score += points);
        _ghostMultiplier++;
    }

    public void PacmanEaten()
    {
        this._pacman.gameObject.SetActive(false);
        SetLives(this.lives--);

        if (this.lives > 0)
        {
            ResetState();
        }
        else
        {
            GameOver();
        }
    }

    public void PelletEaten(Pellet pellet)
    {
        pellet.gameObject.SetActive(false);
        SetScore(score + pellet.points);
        if(!HasRemainingPellets())
        {
            _pacman.gameObject.SetActive(false) ;
            Invoke(nameof(NewRound), 3f);
        }
    }
    public void PowerpelletEaten(Powerpellet pellet)
    {
        PelletEaten(pellet);
        CancelInvoke();
        Invoke(nameof(ResetGhostMultiplier), pellet._duration);
    }

    private bool HasRemainingPellets()
    {
        foreach (Transform pellets in this._pellets)
        {
            if (pellets.gameObject.activeSelf)
            { return true; }

        }
        return false;
    }

    private void ResetGhostMultiplier()
    {
        _ghostMultiplier = 1;
    }

}
