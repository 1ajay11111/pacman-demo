using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Passage : MonoBehaviour
{
   public Transform _connection;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Vector3 Position = collision.transform.position;
        Position.x = -_connection.position.x;
        Position.y = -_connection.position.y;

        collision.transform.position = _connection.position;

    }
}
