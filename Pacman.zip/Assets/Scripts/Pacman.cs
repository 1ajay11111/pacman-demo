using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pacman : MonoBehaviour
{
    public Movement Movement;

    private void Awake()
    {
        Movement = GetComponent<Movement>();
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            Movement.SetDirection(Vector2.up);
        }

        else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            Movement.SetDirection(Vector2.down);
        }

        else if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            Movement.SetDirection(Vector2.left);
        } 

        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            Movement.SetDirection(Vector2.right);
        }

        float _angle = Mathf.Atan2(Movement.direction.y, Movement.direction.x);
        transform.rotation = Quaternion.AngleAxis(_angle * Mathf.Rad2Deg, Vector3.forward);
    }
}
